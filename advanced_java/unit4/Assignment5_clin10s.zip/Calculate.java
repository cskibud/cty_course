package advanced_java.unit4;

public interface Calculate {
    String summarize();
}
