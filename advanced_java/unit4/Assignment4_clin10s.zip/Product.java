package advanced_java.unit4;

public abstract class Product {
    private double cost;
    private double price;

    public Product() {
        this.cost = 0.0;
        this.price = 0.0;
    }
    public Product(double cost, double price) {
        this.cost = cost;
        this.price = price;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
    public double getCost() {
        return this.cost;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public double getPrice() {
        return this.price;
    }

    public void outputProduct() {

    }
}
