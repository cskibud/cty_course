package advanced_java.unit4;
import java.util.*;

public class CalculateDriver {
    public static void main(String[] args) {
        initializeProgram();
        Painting painting = initializePainting();
        Sketch sketch = initializeSketch();
        Photograph photograph = initializePhotograph();
        int orderAmount = getOrderAmount();
        Accounting accountingOrders = getOrders(orderAmount, painting, sketch, photograph);
        displaySummaries(accountingOrders);
    }
    public static void initializeProgram() {
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to the profit and loss calculator");
        System.out.println("Please enter the following information:");
    }
    public static Painting initializePainting() {
        Scanner input = new Scanner(System.in);
        System.out.println("Configure Paintings:");
        System.out.println("Selling Price:");
        double paintingPrice = input.nextDouble();
        System.out.println("Cost to Company:");
        double paintingCost = input.nextDouble();
        Painting painting = new Painting(paintingCost, paintingPrice);
        return painting;
    }
    public static Sketch initializeSketch() {
        Scanner input = new Scanner(System.in);
        System.out.println("Configure Sketches:");
        System.out.println("Selling Price:");
        double sketchPrice = input.nextDouble();
        System.out.println("Cost to Company:");
        double sketchCost = input.nextDouble();
        Sketch sketch = new Sketch(sketchCost, sketchPrice);
        return sketch;
    }
    public static Photograph initializePhotograph() {
        Scanner input = new Scanner(System.in);
        System.out.println("Configure Photographs:");
        System.out.println("Selling Price:");
        double photoPrice = input.nextDouble();
        System.out.println("Cost to Company:");
        double photoCost = input.nextDouble();
        Photograph photograph = new Photograph(photoCost, photoPrice);
        return photograph;
    }
    public static int getOrderAmount() {
        Scanner input = new Scanner(System.in);
        System.out.println("\n");
        System.out.println("How many orders will you be entering?");
        int orderAmount = input.nextInt();
        return orderAmount;
    }
    public static Accounting getOrders(int orderAmount, Painting painting, Sketch sketch, Photograph photograph) {
        Scanner input = new Scanner(System.in);
        OrderItem[] orderItems = new OrderItem[orderAmount];
        for (int i = 0; i < orderAmount; i++) {
            int orderNumber = i + 1;
            System.out.println("Order " + orderNumber + " - which product?\nEnter 1 for Painting, 2 for Sketch, 3 for Photograph:");
            int productType = input.nextInt();
            System.out.println("Order " + orderNumber + " - quantity?");
            int quantity = input.nextInt();
            OrderItem orderItem = null;
            switch(productType) {
                case 1:
                orderItem = new OrderItem(orderNumber, quantity, painting);
                break;
                case 2:
                orderItem = new OrderItem(orderNumber, quantity, sketch);
                break;
                case 3:
                orderItem = new OrderItem(orderNumber, quantity, photograph);
                break;
                default:
                break;
            }
            if (orderItem != null) {
                orderItems[i] = orderItem;
            }
        }
        Order order = new Order(orderItems);
        Order[] orderArray = {order};
        Accounting accountingOrders = new Accounting(orderArray);
        return accountingOrders;
    }
    public static void displaySummaries(Accounting accountingOrders) {
        Order[] orderArray = accountingOrders.getOrders();
        System.out.println("\n");
        System.out.println("Order Summarization: \n*******************************");
        System.out.println(orderArray[0].summarize());
        System.out.println("\n");
        System.out.println("Profit and Loss Calculation: \n*******************************");
        System.out.println(accountingOrders.summarize());
    }
}
