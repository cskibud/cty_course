package advanced_java.midtermProject;

public class HighVolumeCustomer extends Customer{
    public HighVolumeCustomer (String customerName) {
        super(customerName);
    }
}
