package advanced_java.midtermProject;

public class LowVolumeCustomer extends Customer{
    public LowVolumeCustomer (String customerName) {
        super(customerName);
    }
}
