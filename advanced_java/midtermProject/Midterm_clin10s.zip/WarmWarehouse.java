package advanced_java.midtermProject;

public class WarmWarehouse extends Warehouse{
    public WarmWarehouse(String warehouseName) {
        super(warehouseName);
    }
}
