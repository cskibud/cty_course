package advanced_java.midtermProject;

public abstract class Customer {
    protected String customerName;

    public Customer(String customerName) {
        this.customerName = customerName;
    }
}
