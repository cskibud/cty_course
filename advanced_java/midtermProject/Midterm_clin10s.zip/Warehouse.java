package advanced_java.midtermProject;

public abstract class Warehouse {
    protected String warehouseName;

    public Warehouse(String warehouseName) {
        this.warehouseName = warehouseName;
    }
}
