package advanced_java.midtermProject;

public class CoolWarehouse extends Warehouse{
    public CoolWarehouse(String warehouseName) {
        super(warehouseName);
    }
}
