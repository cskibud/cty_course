package print_company;

public class PrintCompany {
    public static void main(String [] args) {
        System.out.println("Company Name: Blue Heart");
        System.out.println("CEO: Chelsea Lin");
        System.out.println("Founding Date: Feb. 2, 2023");
    }
}
