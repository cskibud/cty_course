package print_company;

public class SampleOrder {
    public static void main(String [] args) {
        int amountOfPieces = 3;
        double price = 120.65;
        System.out.println("Thank you for purchasing " + amountOfPieces + " artworks/photographs from BlueHeart!");
        System.out.println("Your total price is $" + price);
    }
}
