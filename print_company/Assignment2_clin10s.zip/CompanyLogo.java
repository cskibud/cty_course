package print_company;

public class CompanyLogo {
    public static void main(String [] args) {
        System.out.println("      *  *            *  *      ");
        System.out.println("  *          *    *          *  ");
        System.out.println("   *            *            *   ");
        System.out.println("       *        B        *       ");
        System.out.println("           *         *           ");
        System.out.println("                *                ");
    }
    
}
